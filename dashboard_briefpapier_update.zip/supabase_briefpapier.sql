-- Run in Supabase SQL Editor. Existing RLS and storage policies remain unchanged.
alter table public.app_settings add column if not exists letterhead_path text;
